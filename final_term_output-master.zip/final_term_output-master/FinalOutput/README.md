# Animated_Flutter_Login_Screen
Chavez, Hugo Leroy //
Gicanal, Flora May // 
Tunggak, Marianne Therese
#
A login page with simple animation.

This project contains the basic features of Flutter Animation that are required to build an amazing Flutter application. 

The login button works by entering an email address and a password (atleast 8 characters and a maximum of 16)

## Below are the screen shots of the login page:

## Login Page
#
![LoginScreen](Screenshots/LoginScreen.png)
## Some Errors
#
![LoginError1](Screenshots/LoginError1.png)
#
![LoginError2](Screenshots/LoginError2.png)
#
![LoginError3](Screenshots/LoginError3.png)
## Sign Up Page
#
![SignUp](Screenshots/SignUp.png)
## Forgot Password Page
#
![ForgotPassword](Screenshots/ForgotPass.png)
## Home Page
#
![HomeScreen](Screenshots/HomeScreen.gif)