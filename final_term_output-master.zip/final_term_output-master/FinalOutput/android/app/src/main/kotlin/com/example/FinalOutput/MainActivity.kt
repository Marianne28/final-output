package com.example.FinalOutput

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
